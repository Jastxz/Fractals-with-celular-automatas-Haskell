module Main where

import Interaction

main :: IO ()
main = mainInteraction
